'use strict';

/*---- Insert CSS -----*/
var head = document.getElementsByTagName('head')[0];
var link = document.createElement('link');
link.rel = 'stylesheet';
link.type = 'text/css';
link.href = browser.runtime.getURL("style.css");
link.media = 'all';
head.appendChild(link);



var joinedText=[]; //hier kommt der gefilterte Text der Website rein
var textPOSTags = [];



// Alphabetical list of PENN part-of-speech tags
// source: https://rednoise.org/rita/reference/PennTags.html
var allPOSTags = [
  'cc',
  'cd',
  'dt',
  'ex',
  'fw',
  'in',
  'jj',
  'jjr',
  'jjs',
  'ls',
  'md',
  'nn',
  'nns',
  'nnp',
  'nnps',
  'pdt',
  'pos',
  'prp',
  'prp$',
  'rb',
  'rbr',
  'rbs',
  'rp',
  'sym',
  'to',
  'uh',
  'vb',
  'vbd',
  'vbg',
  'vbn',
  'vbp',
  'vbz',
  'wdt',
  'wp',
  'wp$',
  'wrb'
];
var allPOSTagsFull = [
  'Coordinating conjunction',
  'Cardinal number',
  'Determiner',
  'Existential there',
  'Foreign word',
  'Preposition or subordinating conjunction',
  'Adjective',
  'Adjective, comparative',
  'Adjective, superlative',
  'List item marker',
  'Modal',
  'Noun, singular or mass',
  'Noun, plural',
  'Proper noun, singular',
  'Proper noun, plural',
  'Predeterminer',
  'Possessive ending',
  'Personal pronoun',
  'Possessive pronoun',
  'Adverb',
  'Adverb, comparative',
  'Adverb, superlative',
  'Particle',
  'Symbol',
  'to',
  'Interjection',
  'Verb, base form',
  'Verb, past tense',
  'Verb, gerund or present participle',
  'Verb, past participle',
  'Verb, non-3rd person singular present',
  'Verb, 3rd person singular present',
  'Wh-determiner',
  'Wh-pronoun',
  'Possessive wh-pronoun',
  'Wh-adverb'
];

var counters = [];

var posX;
var posY;

var drawGreyLines = false;
var drawColoredLines = true;
var drawText = true;

let offsetX = 0;
let offsetY = 0;
let dragX = 0;
let dragY = 0;

const s = function (p5){

  /*
p5.preload = function(){
        joinedText = p5.loadStrings(browser.runtime.getURL('data/AllTheWorldsAStage.txt'));
    }*/

let cnv;
p5.setup = function () {
    cnv=p5.createCanvas(p5.windowWidth, p5.windowHeight);
    p5.colorMode(p5.HSB, 360, 100, 100, 100);
  
    p5.textFont('Helvetica', 20);
    p5.fill(0);
  
    for (var i = 0; i < allPOSTags.length; i++) {
      counters.push(0);
    }
  
    joinedText = joinedText.join(' ');
    joinedText = joinedText.split(/\s+/);
    for (var i = 0; i < joinedText.length; i++) {
  
      var wordPOSTag = RiTa.getPosTags(RiTa.stripPunctuation(joinedText[i]))[0];
  
      textPOSTags.push(wordPOSTag);
  
      var tagIndex = allPOSTags.indexOf(wordPOSTag);
      if (tagIndex >= 0) {
        counters[tagIndex]++;
      }
  
      joinedText[i] += ' ';
  
    }

     cnv.mousePressed(p5.startDrag);
     cnv.mouseReleased(p5.endDrag);
  }
  
  let maxLineLength=0;
  p5.draw = function() {
    p5.clear();
    p5.translate(50, 0);
    //p5.translate(offsetX + dragX+50, offsetY + dragY);
  
    p5.noStroke();
  
    posX = 0;
    posY = 50;
    var sortPositionsX = [];
    var sortPositionsY = [];
    var oldPositionsX = [];
    var oldPositionsY = [];
    for (var i = 0; i < joinedText.length; i++) {
      sortPositionsX[i] = 0;
      oldPositionsX[i] = 0;
      oldPositionsY[i] = 0;
    }
    var oldX = 0;
    var oldY = 0;
  
    // draw counters
    if (p5.mouseX >= p5.width - 50) {
        p5.textSize(10);//INDEX AUF DER LINKEN SEITE
      for (var i = 0; i < allPOSTags.length; i++) {
        p5.textAlign(p5.LEFT);
        p5.text(allPOSTags[i] + ' (' + allPOSTagsFull[i] + ')', -20, i * 20 + 40);
        p5.textAlign(p5.RIGHT);
        p5.text(counters[i], -25, i * 20 + 40);
      }
      p5.textAlign(p5.LEFT);
      p5.textSize(20);//STICHWOERTER
    }
  
    p5. translate(256, 0);
  
    // go through all characters in the text to draw them
    for (var i = 0; i < joinedText.length; i++) {
      var z=1;//zeile
      // again, find the index of the current letter in the alphabet
      var wordPOSTag = textPOSTags[i];
      var index = allPOSTags.indexOf(wordPOSTag);
      if (index < 0) continue;
  
      var m = p5.map(p5.mouseX, 50, p5.width - 50, 0, 1);
      m = p5.constrain(m, 0, 1);
  
      var sortX = sortPositionsX[index];
      var interX = p5.lerp(posX, sortX, m);
  
      var sortY = index * 20 + 40;
 
      var interY = p5.lerp(posY, sortY, m);
  
      if (drawGreyLines) {
        if (oldX != 0 && oldY != 0) {
            p5.stroke(0, 10);
            p5.line(oldX, oldY, interX, interY);
        }
        oldX = interX;
        oldY = interY;
      }
  
      if (drawColoredLines) {
        if (oldPositionsX[index] != 0 && oldPositionsY[index] != 0) {
            p5.stroke(index * 10, 80, 60, 50);
            p5.line(oldPositionsX[index], oldPositionsY[index], interX, interY);
        }
        oldPositionsX[index] = interX;
        oldPositionsY[index] = interY;
      }
  
      if (drawText) {
        p5.text(joinedText[i], interX, interY);
      }
  
      sortPositionsX[index] += p5.textWidth(joinedText[i]);//

      if(sortPositionsX[index] > maxLineLength){
        maxLineLength=sortPositionsX[index];
      }
      
      posX += p5.textWidth(joinedText[i]);
     if (posX >= p5.min(p5.width, 1000)) {
        posY += 40;
        posX = 0;
      }
    }

    
  }

p5.startDrag=function() {
  dragX = 0;
  dragY = 0;
}

p5.endDrag=function() {
  offsetX += dragX;
  offsetY += dragY;
}

p5.mouseDragged=function() {
  dragX = p5.mouseX - p5.pmouseX;
  dragY = p5.mouseY - p5.pmouseY;
}
 
}
//---PARSEN der Website 
//step 1 Content sortiert nach Tags
let sortedNodes = [];

function travelAllNodes(node) {
    if (node.nodeType === Node.ELEMENT_NODE) {
        let tag = sortedNodes.find(obj => obj.tag === node.nodeName);
        if (tag === undefined) {
            sortedNodes.push({ "tag": node.nodeName, "elements": [node] })
        } else {
            tag.elements.push(node);
        }
    }

    for (let i = 0; i < node.childNodes.length; i++) {
        const childNode = node.childNodes[i];
        travelAllNodes(childNode);
    }
}

travelAllNodes(document.body);

//step 2 filtern nach tags, hier als beispiel h2
//filtern nach bestimmtem Tag -> H2
let tag = sortedNodes.find(obj => obj.tag === "H2");

for (let i = 0; i < tag.elements.length; i++) {
  joinedText.push(tag.elements[i].textContent); 
}

tag = sortedNodes.find(obj => obj.tag === "H1");

for (let i = 0; i < tag.elements.length; i++) {
  joinedText.push(tag.elements[i].textContent);   
}


///hier wird der p5 Sketch gestartet
const myp5 = new p5(s);



window.addEventListener('scroll', function() {
  var scrollTop = window.pageYOffset || document.documentElement.scrollTop;
  var overlayElement = document.createElement('div');
  overlayElement.style.position = 'fixed';
  overlayElement.style.top = '0';
  overlayElement.style.left = '0';
  overlayElement.style.width = '100%';
  overlayElement.style.height = '100%';
  overlayElement.style.zIndex = '10';
  overlayElement.style.background = 'rgba(0, 255, 0, ' + (scrollTop / 10000) + ')';
  overlayElement.style.backdropFilter = 'blur(' + (scrollTop / 100) + 'px)';

  // Remove any previously added overlay elements
  var previousOverlay = document.getElementById('scrollOverlay');
  if (previousOverlay) {
    previousOverlay.parentNode.removeChild(previousOverlay);
  }

  overlayElement.id = 'scrollOverlay';
  document.body.appendChild(overlayElement);
});



/* This extension is heavily based on the code P_3_1_3_05 generative-gestaltung.de */
/* Original is Licenced unter http://www.apache.org/licenses/LICENSE-2.0 */ 

// P_3_1_3_05
//
// Generative Gestaltung – Creative Coding im Web
// ISBN: 978-3-87439-902-9, First Edition, Hermann Schmidt, Mainz, 2018
// Benedikt Groß, Hartmut Bohnacker, Julia Laub, Claudius Lazzeroni
// with contributions by Joey Lee and Niels Poldervaart
// Copyright 2018
//
// http://www.generative-gestaltung.de
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.